package com.cts.bankmanagement.dao;

import java.util.Date;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.cts.bankmanagement.vo.TrainerVO;

@Repository("viewDAO")
public class ViewDAOImpl implements ViewDAO {

	@Autowired
	private SessionFactory sessionFactory;

	@Override
	public List<TrainerVO> getWeeklyDetails(Date startDate) {
		System.out.println("inside view dao");
		java.sql.Date s1=new java.sql.Date(startDate.getTime());
		System.out.println(s1);
		Query query=sessionFactory.getCurrentSession().createQuery("from ScheduleTraining where startDate=:startDate");
		//query.setParameter("startDate", startDate);
		//query.setDate("startDate", startDate);
		query.setTimestamp("startDate", s1);
		System.out.println(query.list());
		@SuppressWarnings("unchecked")
		List<TrainerVO> list=query.list();
		System.out.println(list);
		return list;
	}
}
