package com.cts.bankmanagement.dao;

import com.cts.bankmanagement.vo.TrainerVO;

public interface ScheduleDAO {
 
	public void insert(TrainerVO trainerVO); 
}
