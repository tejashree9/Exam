package com.cts.bankmanagement.service;

import com.cts.bankmanagement.vo.TrainerVO;

public interface ScheduleServiceI {
	public void insert(TrainerVO trainerVO) ;
}
